from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

WEATHER_API_KEY = "7e546741e4d24f2f88083023253101"

@app.route('/weather')
def get_weather():
    lat = request.args.get('lat')
    lon = request.args.get('lon')
    weather_url = f"http://api.weatherapi.com/v1/current.json?key={WEATHER_API_KEY}&q={lat},{lon}"
    
    response = requests.get(weather_url)
    if response.status_code == 200:
        data = response.json()
        return jsonify({
            "temp": data['current']['temp_c'],
            "condition": data['current']['condition']['text']
        })
    return jsonify({"error": "Weather data not available"}), 500

@app.route('/news') 
def get_news():
    news_data = "Stock Market: Sensex up 200 points | Traffic Update: Heavy congestion on MG Road"
    return jsonify({"news": news_data})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)

